import { prisma } from "@/lib/prisma";
import Link from "next/link";

export default async function Tokens() {
  const tokens = await prisma.token.findMany({ take: 50, orderBy: { createdAt: "desc" } });
  return (
    <div className="grid md:grid-cols-3 gap-4">
      {tokens.map(t => (
        <Link key={t.id} href={`/token/evm/${t.address}`} className="card">
          <div className="font-semibold">{t.name} <span className="opacity-70">({t.symbol})</span></div>
          <div className="text-sm opacity-70">{t.chain} — {t.address.slice(0,8)}…</div>
          {t.burnedSupply && <div className="text-xs mt-2">Supply burned: {t.burnedSupply}</div>}
        </Link>
      ))}
    </div>
  );
}
