'use client';

import { WagmiProvider, createConfig, http } from "wagmi";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { RainbowKitProvider, getDefaultConfig, ConnectButton } from "@rainbow-me/rainbowkit";
import { mainnet, sepolia, bscTestnet } from "wagmi/chains";
import "@rainbow-me/rainbowkit/styles.css";
import { useEffect } from "react";

// Solana
import { ConnectionProvider, WalletProvider } from "@solana/wallet-adapter-react";
import { WalletAdapterNetwork } from "@solana/wallet-adapter-base";
import { PhantomWalletAdapter } from "@solana/wallet-adapter-wallets";

const wc = process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID!;

const wagmiConfig = getDefaultConfig({
  appName: "AstroLaunch",
  projectId: wc,
  chains: [mainnet, sepolia, bscTestnet],
  ssr: true,
});

const queryClient = new QueryClient();

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <WagmiProvider config={wagmiConfig}>
      <QueryClientProvider client={queryClient}>
        <RainbowKitProvider>
          <ConnectionProvider endpoint={process.env.NEXT_PUBLIC_SOLANA_RPC!}>
            <WalletProvider wallets={[new PhantomWalletAdapter({ network: WalletAdapterNetwork.Mainnet })]} autoConnect>
              <MountWalletButtons />
              {children}
            </WalletProvider>
          </ConnectionProvider>
        </RainbowKitProvider>
      </QueryClientProvider>
    </WagmiProvider>
  );
}

function MountWalletButtons() {
  // Mount React portals into layout placeholders
  useEffect(() => {
    const evm = document.getElementById("evm-wallet");
    if (evm) {
      import("react-dom").then(({ createRoot }) => {
        const root = createRoot(evm);
        root.render(<ConnectButton />);
      });
    }
  }, []);
  return null;
}
