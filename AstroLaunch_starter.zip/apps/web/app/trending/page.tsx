import { Suspense } from "react";
import Tokens from "./tokens";

export default function TrendingPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Trending</h1>
      <Suspense fallback={<div>Loading...</div>}>
        <Tokens />
      </Suspense>
    </div>
  );
}
