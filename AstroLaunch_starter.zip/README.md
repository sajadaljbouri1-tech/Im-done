# AstroLaunch — Monorepo Starter

This repository provides a **production-ready starter** for AstroLaunch with:
- **Next.js 14 (App Router) + Tailwind + shadcn/ui** frontend
- **Wallets**: EVM (MetaMask etc. via wagmi + RainbowKit) and **Solana** (wallet-adapter)
- **Token pages** with **DexScreener** embeds
- **Token creation flow** (EVM via Solidity factory; BNB supported as it’s EVM-compatible)
- **Liquidity lock** (basic ERC20 timelock for LP tokens)
- **Roadmap UI**, Featured/Trending, Countdown, and basic CMS via Prisma (SQLite by default)
- **API route handlers** inside Next.js for tokens & creator profiles

> **Important:** This code implements a **clearly disclosed 1% platform fee** option for created tokens. I will **not** implement hidden or deceptive fees. Be transparent with users and comply with your local laws and exchange/listing policies.

## Quick Start

```bash
# 1) Install Node 20+ and pnpm (recommended) or npm
corepack enable
# 2) Install deps
cd apps/web
pnpm install
# 3) Setup env
cp .env.example .env.local
# 4) Initialize DB (SQLite default)
pnpm prisma migrate dev
# 5) Dev server
pnpm dev
```

Contracts:
```bash
cd contracts
pnpm install
pnpm hardhat compile
pnpm hardhat run scripts/deploy.ts --network <your_network>
```

## Structure

- `apps/web/` — Next.js frontend + API routes
- `contracts/` — Solidity contracts (TaxedERC20, TokenFactory, LiquidityLocker)

## Environment

Create `apps/web/.env.local`:

```
# EVM
NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID=your_walletconnect_id
NEXT_PUBLIC_PLATFORM_FEE_BPS=100     # 1% fee (100 basis points)
NEXT_PUBLIC_PLATFORM_FEE_WALLET=0x0000000000000000000000000000000000000000

# Solana
NEXT_PUBLIC_SOLANA_RPC=https://api.mainnet-beta.solana.com

# Database (Prisma - SQLite default)
DATABASE_URL="file:./dev.db"
```

## Notes

- **BNB Chain** works through the same EVM wallet flow.
- **Solana token creation** is stubbed in UI and hooks. Implement your program or integrate with your chosen service.
- The Liquidity Locker is a simple ERC20 time lock for LP tokens. Use audited lockers in production.
- Always disclose fees to users. This repo **does not** hide fees.
