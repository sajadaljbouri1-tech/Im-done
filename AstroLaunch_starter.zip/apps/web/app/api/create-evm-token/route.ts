import { NextRequest, NextResponse } from "next/server";
import { Address, createPublicClient, createWalletClient, http, parseEther } from "viem";
import { sepolia } from "viem/chains";
import { prisma } from "@/lib/prisma";

// Simplified. In production, call your factory via a server-side signer or delegates.
export async function POST(req: NextRequest) {
  try {
    const { name, symbol, supply } = await req.json();
    if (!name || !symbol || !supply) return NextResponse.json({ error: "Missing fields" }, { status: 400 });

    // Demo: pretend address created (replace with real on-chain tx + events)
    const fakeAddr = ("0x" + Buffer.from(name + symbol).toString("hex").slice(0, 40)).padEnd(42, "0") as Address;

    await prisma.token.create({
      data: {
        chain: "evm",
        address: fakeAddr,
        name, symbol,
        createdBy: "demo"
      }
    });

    return NextResponse.json({ address: fakeAddr });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
