'use client';
export default function Dex({ address }: { address: string }) {
  return (
    <div className="w-full aspect-video card">
      <iframe
        src={`https://dexscreener.com/ethereum/${address}?embed=1&theme=${typeof window !== 'undefined' && document.documentElement.classList.contains('dark') ? 'dark' : 'light'}`}
        className="w-full h-full rounded-xl"
        allowFullScreen
      />
    </div>
  );
}
