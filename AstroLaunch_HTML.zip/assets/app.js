
(function(){
  const $ = sel => document.querySelector(sel);
  const $$ = sel => Array.from(document.querySelectorAll(sel));

  // THEME
  const themeBtn = $("#theme-toggle");
  const savedTheme = localStorage.getItem("theme") || "dark";
  if(savedTheme === "dark"){ document.documentElement.classList.add("dark"); }
  if(themeBtn){
    themeBtn.addEventListener("click", () => {
      document.documentElement.classList.toggle("dark");
      localStorage.setItem("theme", document.documentElement.classList.contains("dark") ? "dark" : "light");
    });
  }

  // COUNTDOWN
  window.initCountdown = function(el, targetIso){
    function tick(){
      const t = new Date(targetIso).getTime() - Date.now();
      if(t <= 0){ el.textContent = "Launching!"; return; }
      const d = Math.floor(t/86400000);
      const h = Math.floor((t%86400000)/3600000);
      const m = Math.floor((t%3600000)/60000);
      const s = Math.floor((t%60000)/1000);
      el.textContent = d+"d "+h+"h "+m+"m "+s+"s";
    }
    tick(); setInterval(tick,1000);
  }

  // TOKEN STORAGE (local demo)
  function getTokens(){
    try{ return JSON.parse(localStorage.getItem("tokens")||"[]"); }catch{ return []; }
  }
  function setTokens(arr){ localStorage.setItem("tokens", JSON.stringify(arr)); }
  function hexFrom(str){
    // simple hash -> 40 hex chars
    const bytes = new TextEncoder().encode(str);
    let h = 0; for (let b of bytes){ h = (h*31 + b) >>> 0; }
    let hex = (h>>>0).toString(16);
    while(hex.length < 40) hex = hex + hex;
    return "0x" + hex.slice(0,40);
  }
  window.demoCreateToken = function({name, symbol, supply, chain}){
    const address = hexFrom(name+symbol);
    const tokens = getTokens();
    const tok = {id: address, name, symbol, chain: chain||"ethereum", address, createdAt: Date.now(), featured:false, editorsPick:false};
    tokens.unshift(tok); setTokens(tokens);
    return tok;
  }
  window.loadTokens = getTokens;

  // TRENDING PAGE RENDER
  window.renderTrending = function(container){
    const tokens = getTokens();
    if(tokens.length === 0){
      // seed demo tokens
      ["ASTRO","MOON","STAR","ROCKET","COMET"].forEach((sym,i)=>{
        const t = demoCreateToken({name:sym+" Token", symbol:sym, supply: "1000000", chain:"ethereum"});
        if(i===0) t.featured = true;
        setTokens(getTokens());
      });
    }
    const list = getTokens();
    container.innerHTML = list.map(t => `
      <a class="card token-card" href="token.html?address=${t.address}&chain=${t.chain}&name=${encodeURIComponent(t.name)}&symbol=${encodeURIComponent(t.symbol)}">
        <div class="title">${t.name} <span class="small">(${t.symbol})</span></div>
        <div class="meta">${t.chain} — ${t.address.slice(0,10)}…</div>
      </a>
    `).join("");
  }

  // TOKEN PAGE RENDER
  window.renderTokenPage = function(){
    const p = new URLSearchParams(location.search);
    const address = p.get("address");
    const chain = p.get("chain") || "ethereum";
    const name = p.get("name") || "";
    const symbol = p.get("symbol") || "";
    const title = $("#token-title");
    if(title){ title.textContent = name ? `${name} (${symbol})` : address; }
    const iframe = $("#dex-embed");
    if(iframe && address){
      iframe.src = `https://dexscreener.com/${chain}/${address}?embed=1&theme=${document.documentElement.classList.contains("dark") ? "dark" : "light"}`;
    }
  }

  // CREATE PAGE
  const createForm = $("#create-form");
  if(createForm){
    createForm.addEventListener("submit", (e)=>{
      e.preventDefault();
      const name = $("#name").value.trim();
      const symbol = $("#symbol").value.trim().toUpperCase();
      const supply = $("#supply").value.trim();
      const chain = $("#chain").value;
      if(!name || !symbol || !supply){ alert("Fill all fields"); return; }
      const token = demoCreateToken({name, symbol, supply, chain});
      location.href = `token.html?address=${token.address}&chain=${token.chain}&name=${encodeURIComponent(token.name)}&symbol=${encodeURIComponent(token.symbol)}`;
    });
  }

  // EMAIL CAPTURE
  const emailForm = $("#email-form");
  if(emailForm){
    emailForm.addEventListener("submit",(e)=>{
      e.preventDefault();
      const v = $("#email").value.trim();
      if(!v || !v.includes("@")){ alert("Enter a valid email"); return; }
      const subs = JSON.parse(localStorage.getItem("subscribers")||"[]");
      subs.push({email:v, at: Date.now()}); localStorage.setItem("subscribers", JSON.stringify(subs));
      $("#email").value = ""; alert("Thanks! You’re on the list.");
    });
  }

  // ACTIVE NAV
  (function(){
    const path = location.pathname.split("/").pop() || "index.html";
    document.querySelectorAll('.nav a').forEach(a=>{
      const href = a.getAttribute("href");
      if((path === "index.html" && href === "index.html") || (href !== "index.html" && path.startsWith(href.replace("./","")))){
        a.style.borderColor = "var(--border)";
        a.style.background = "#0e1430";
      }
    });
  })();

})();
