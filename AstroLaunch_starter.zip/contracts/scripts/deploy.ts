import { ethers } from "hardhat";

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying with:", deployer.address);

  const platformFeeWallet = process.env.PLATFORM_FEE_WALLET || deployer.address;
  const platformFeeBps = Number(process.env.PLATFORM_FEE_BPS || "100"); // 1%

  const Factory = await ethers.getContractFactory("TokenFactory");
  const factory = await Factory.deploy(platformFeeWallet, platformFeeBps);
  await factory.waitForDeployment();
  console.log("TokenFactory deployed at:", await factory.getAddress());
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
