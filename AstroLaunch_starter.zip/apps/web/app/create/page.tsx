'use client';

import { useState } from "react";
import { useAccount } from "wagmi";
import { toast } from "react-hot-toast";

export default function CreatePage() {
  const { address } = useAccount();
  const [form, setForm] = useState({ name: "", symbol: "", supply: "1000000" });

  async function submit() {
    try {
      const res = await fetch("/api/create-evm-token", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed");
      toast.success("Token created!");
      window.location.href = `/token/evm/${data.address}`;
    } catch (e:any) {
      toast.error(e.message);
    }
  }

  return (
    <div className="max-w-xl card space-y-4">
      <h1 className="text-2xl font-bold">Create EVM Token</h1>
      <label className="block">Name
        <input className="w-full border rounded-xl px-3 py-2" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} />
      </label>
      <label className="block">Symbol
        <input className="w-full border rounded-xl px-3 py-2" value={form.symbol} onChange={e=>setForm({...form, symbol:e.target.value})} />
      </label>
      <label className="block">Initial Supply
        <input type="number" className="w-full border rounded-xl px-3 py-2" value={form.supply} onChange={e=>setForm({...form, supply:e.target.value})} />
      </label>
      <div className="text-sm opacity-80">
        Platform fee: {(Number(process.env.NEXT_PUBLIC_PLATFORM_FEE_BPS)/100).toFixed(2)}% — sent to {process.env.NEXT_PUBLIC_PLATFORM_FEE_WALLET}
      </div>
      <button onClick={submit} className="px-4 py-2 rounded-xl bg-black text-white dark:bg-white dark:text-black">Create</button>
      {!address && <p className="text-sm opacity-70">Connect your EVM wallet to proceed.</p>}
      <p className="text-xs opacity-60">Solana token creation is stubbed here; integrate your on-chain program later.</p>
    </div>
  );
}
