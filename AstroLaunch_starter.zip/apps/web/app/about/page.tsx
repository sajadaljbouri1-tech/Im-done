export default function About() {
  return (
    <div className="prose dark:prose-invert">
      <h1>About AstroLaunch</h1>
      <p>AstroLaunch helps creators launch tokens transparently across chains with tools like liquidity lock and Dex embeds.</p>
      <h2>Roadmap (Highlights)</h2>
      <ul>
        <li>NFT marketplace and profile-picture support</li>
        <li>Creator verification and reliability badges</li>
        <li>Multi-chain expansion</li>
      </ul>
    </div>
  );
}
