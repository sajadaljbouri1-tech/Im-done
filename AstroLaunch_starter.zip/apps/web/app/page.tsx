import Link from "next/link";

export default function Home() {
  return (
    <section className="grid md:grid-cols-2 gap-8 items-center">
      <div className="space-y-6">
        <h1 className="text-5xl font-extrabold">Launch tokens in minutes.</h1>
        <p className="text-lg opacity-90">
          Multi-chain creation, transparent fees, liquidity lock, and real-time charts.
        </p>
        <div className="flex gap-3">
          <Link href="/create" className="px-5 py-3 rounded-2xl bg-black text-white dark:bg-white dark:text-black">Create Token</Link>
          <Link href="/trending" className="px-5 py-3 rounded-2xl border">Browse Trending</Link>
        </div>
        <ul className="grid grid-cols-2 gap-3 text-sm">
          <li className="card">✅ 1% platform fee disclosed</li>
          <li className="card">🔒 Liquidity lock support</li>
          <li className="card">🧩 Renounce & Burn options</li>
          <li className="card">📈 DexScreener embeds</li>
        </ul>
      </div>
      <div className="card">
        <h2 className="text-xl font-semibold mb-2">Countdown to Launch</h2>
        <Countdown target="2025-08-07T00:00:00+10:00" />
      </div>
    </section>
  );
}

function Countdown({ target }: { target: string }) {
  return (
    <div>
      <p className="opacity-80">Website launch: <b>7 Aug 2025 (AEST)</b></p>
      <p className="mt-2 text-sm opacity-70">Add a fancy animated countdown here.</p>
    </div>
  );
}
