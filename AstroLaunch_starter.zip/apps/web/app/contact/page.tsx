export default function Contact() {
  return (
    <div className="max-w-lg card space-y-3">
      <h1 className="text-2xl font-bold">Contact Us</h1>
      <p className="text-sm opacity-80">Email: support@astrolaunch.xyz</p>
      <p className="text-sm opacity-80">Join our Discord & Telegram (add links)</p>
    </div>
  );
}
