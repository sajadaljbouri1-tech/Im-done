import "./globals.css";
import { ReactNode } from "react";
import { Providers } from "./providers";
import Link from "next/link";

export const metadata = {
  title: "AstroLaunch",
  description: "Create and discover tokens across chains."
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <Providers>
          <header className="border-b">
            <div className="container flex items-center gap-6 h-16">
              <Link href="/" className="font-bold text-xl">🚀 AstroLaunch</Link>
              <nav className="ml-auto flex items-center gap-4">
                <Link href="/trending">Trending</Link>
                <Link href="/create">Create</Link>
                <Link href="/about">About</Link>
                <Link href="/contact">Contact</Link>
                <ThemeToggle />
                <WalletButtons />
              </nav>
            </div>
          </header>
          <main className="container py-8">{children}</main>
          <footer className="border-t">
            <div className="container py-6 text-sm opacity-70">
              © {new Date().getFullYear()} AstroLaunch • Platform fee: {(Number(process.env.NEXT_PUBLIC_PLATFORM_FEE_BPS) / 100).toFixed(2)}%
            </div>
          </footer>
        </Providers>
      </body>
    </html>
  );
}

function ThemeToggle() {
  return (
    <button
      className="px-3 py-1 rounded-xl border"
      onClick={() => document.documentElement.classList.toggle("dark")}
    >
      🌓
    </button>
  );
}

function WalletButtons() {
  return (
    <div className="flex gap-2">
      <div id="evm-wallet" />
      <div id="sol-wallet" />
    </div>
  );
}
