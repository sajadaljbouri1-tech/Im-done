import Dex from "@/components/Dex";
import { prisma } from "@/lib/prisma";

export default async function TokenPage({ params }: any) {
  const { chain, address } = params;
  const token = await prisma.token.findFirst({ where: { address } });
  const title = token ? `${token.name} (${token.symbol})` : address;

  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">{title}</h1>
      <Dex address={address} />
      <div className="card">
        <h2 className="font-semibold mb-2">About</h2>
        <p className="text-sm opacity-80">
          This page embeds DexScreener charts for convenience. Do your own research.
        </p>
      </div>
    </div>
  );
}
